var word = 'JavaScript';
var second = 'is';
var third = 'awesome';
var fourth = 'and';
var fifth = 'I';
var sixth = 'love';
var seventh = 'it!';

console.log(word+ " "+second+" "+third+" "+fourth+" "+fifth+" "+sixth+" "+seventh);